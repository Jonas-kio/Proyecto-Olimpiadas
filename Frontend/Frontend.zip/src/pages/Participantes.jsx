import React from "react";

const Participantes = () => {
    return <h1>Página de Participantes</h1>;
};

export default Participantes;