import React from "react";

const Reportes = () => {
    return <h1>Página de Reportes</h1>;
};

export default Reportes;