/* eslint-disable react/prop-types */
/* import '../../styles/components/ContentConfig.css' */

const ContentConfig = ({children }) => {
  return (
    <div className="content-config">
      {children}
    </div>
  );
};

export default ContentConfig;