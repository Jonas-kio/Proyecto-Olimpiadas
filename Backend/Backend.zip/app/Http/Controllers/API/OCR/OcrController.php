<?php

namespace App\Http\Controllers\API\OCR;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OcrController extends Controller
{
    //
}
