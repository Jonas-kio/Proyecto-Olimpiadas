<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\EmailServiceProvider::class,
    App\Providers\OcrServiceProvider::class,
    App\Providers\PdfServiceProvider::class,
];
